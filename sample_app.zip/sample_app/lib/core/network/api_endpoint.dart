
class ApiEndPoint{
  static const baseURL = 'http://restapi.adequateshop.com';
  static const loginEndPoint = "$baseURL/api/authaccount/login";
  static const registerEndPoint = "$baseURL/api/authaccount/registration";
}