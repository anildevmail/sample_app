//Routes
import 'package:flutter/material.dart';
import 'package:sample_app/features/login/presentation/page/login.dart';
import 'package:sample_app/features/splash/presentation/page/splash_screen.dart';

import '../../features/signup/presentation/page/signup.dart';

const splashRoute = '/splash';
const String loginRoute = '/login';
const String signupRoute = '/signup';
const String dashboardRoute = '/dashboard';
const String postRoute = '/post';

class AppRouter {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case splashRoute:
        return MaterialPageRoute(builder: (_) => const SplashScreen());
      case loginRoute:
        return MaterialPageRoute(builder: (_) => const Login());
      case signupRoute:
        return MaterialPageRoute(builder: (_) => const SignUp());
      default:
        return MaterialPageRoute(builder: (_) => const Login());
    }
  }
}
