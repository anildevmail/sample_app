import 'package:flutter/material.dart';

class AppColors{
  ///Blue Color
  // static const primaryColor = Color(0xff5d0cc0);
  // static const primaryColorDark = Color(0xff3e0286);
  // static const primaryColorLight = Color(0xff9f6af5);
  static const primaryColor = Color(0xFF00BCD4);
  static const primaryColorDark = Color(0xFF00ACC1);
  static const primaryColorLight = Color(0xFF26C6DA);

  static const colorTransparent = Color(0x00ffffff);
  static const darkGray = Color(0xff737373);
  static const white = Color(0xffffffff);
  static const black = Color(0xff000000);

}