import 'dart:convert';

import 'package:dartz/dartz.dart';
import 'package:sample_app/core/error/app_exceptions.dart';
import 'package:sample_app/core/network/api_client.dart';
import 'package:sample_app/core/network/api_endpoint.dart';
import 'package:sample_app/core/network/response_handler.dart';
import 'package:sample_app/features/signup/data/models/signup_model.dart';
import 'package:sample_app/features/signup/domain/entities/signup_entity.dart';
import 'package:flutter/material.dart';

abstract class SignupRemoteDataSource {
  Future<Either<BaseException, SignupEntity>> signup(
      String userName, String email, String password);
}

class SignupRemoteDataSourceImpl extends SignupRemoteDataSource {
  @override
  Future<Either<BaseException, SignupEntity>> signup(
      String userName, String email, String password) async {
    var signupResponse = await ApiClient()
        .signup(ApiEndPoint.registerEndPoint, userName, email, password);
    var response = responseHandler(signupResponse);
    debugPrint('Response ${signupResponse.body}');
    return response.fold((l) {
      return Left(l);
    }, (r) {
      return Right(SignupModel.fromJson(jsonDecode(r.body)));
    });
  }
}
