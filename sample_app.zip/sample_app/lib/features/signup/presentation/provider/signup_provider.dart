
import 'package:sample_app/features/signup/domain/entities/signup_entity.dart';
import 'package:sample_app/features/signup/domain/usecases/signup_usecases.dart';
import 'package:flutter/material.dart';

class SignupProvider extends ChangeNotifier{

  final userNameController = TextEditingController(text: 'Anil');
  final emailController = TextEditingController(text:'sample_app@gmail.com');
  final passwordController = TextEditingController(text: 'Anil@123');

  String getUserName(){
    return userNameController.text;
  }

  String getEmail(){
    return emailController.text;
  }

  String getPassword(){
    return passwordController.text;
  }

  final SignupUseCases _signupUseCases = SignupUseCases();

  late SignupEntity _signupEntity;

  SignupEntity get signupEntity => _signupEntity;

  Future<void> signupUser(String userName,String email,String password) async {
    var response = await _signupUseCases.call(SignupParams(userName: userName,email: email, password: password));
    response.fold((l) {
      debugPrint('Left ${l.message}');
    } , (r) {
      debugPrint('Right ${r.data!.Email}');
    });
    notifyListeners();
  }

}