import 'package:dartz/dartz.dart';
import 'package:sample_app/core/error/app_exceptions.dart';
import 'package:sample_app/features/signup/domain/entities/signup_entity.dart';

abstract class SignupRepository{
  Future<Either<BaseException, SignupEntity>> signupUser(String userName, String email, String password);
}