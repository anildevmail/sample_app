import 'package:sample_app/core/utils/app_router.dart';
import 'package:sample_app/features/login/presentation/provider/login_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class Login extends StatelessWidget {
  const Login({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
        create: (_) => LoginProvider(),
        builder: (context, child) {
          return Consumer<LoginProvider>(builder: (context, data, _) {
            return Scaffold(
              body: Container(
                margin: const EdgeInsets.all(24),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _header(context),
                    _inputField(context,data),
                    _forgotPassword(context),
                    _signup(context),
                  ],
                ),
              ),
            );
          });
        });

  }

  _header(context) {
    return const Column(
      children: [
        Text(
          "Welcome to",
          style: TextStyle(fontSize: 24),
        ),
        Text("sample_app",
            style: TextStyle(
                fontFamily: 'Pacifico',
                fontSize: 32.0,
                color: Colors.cyan,
                fontWeight: FontWeight.bold)),
        Padding(
          padding: EdgeInsets.only(top: 32.0),
          child: Text("Enter your credential to login"),
        ),
      ],
    );
  }

  _inputField(context,LoginProvider data) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        TextField(
          controller: data.emailController,
          decoration: InputDecoration(
              hintText: "Username",
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: BorderSide.none),
              fillColor: Colors.cyan.withOpacity(0.1),
              filled: true,
              prefixIcon: const Icon(Icons.person)),
        ),
        const SizedBox(height: 16),
        TextField(
          controller: data.passwordController,
          decoration: InputDecoration(
            hintText: "Password",
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(18),
                borderSide: BorderSide.none),
            fillColor: Colors.cyan.withOpacity(0.1),
            filled: true,
            prefixIcon: const Icon(Icons.password),
          ),
          obscureText: true,
        ),
        const SizedBox(height: 36),
        ElevatedButton(
          onPressed: () {
            data.loginUser(context,data.emailController.text, data.passwordController.text);
          },
          style: ElevatedButton.styleFrom(
            shape: const StadiumBorder(),
            padding: const EdgeInsets.symmetric(vertical: 16),
            backgroundColor: Colors.cyan,
          ),
          child: const Text(
            "Login",
            style: TextStyle(fontSize: 20, color: Colors.white),
          ),
        )
      ],
    );
  }

  _forgotPassword(context) {
    return TextButton(
      onPressed: () {},
      child: const Text(
        "Forgot password?",
        style: TextStyle(color: Colors.cyan),
      ),
    );
  }

  _signup(context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text("Dont have an account? "),
        TextButton(
            onPressed: () {
              Navigator.pushNamed(context, signupRoute);
            },
            child: const Text(
              "Sign Up",
              style: TextStyle(color: Colors.cyan),
            ))
      ],
    );
  }
}

/*import 'package:sample_app/core/utils/app_colors.dart';
import 'package:sample_app/features/login/presentation/provider/login_provider.dart';
import 'package:sample_app/features/login/presentation/widgets/login_input_fields.dart';
import 'package:flutter/material.dart';


class Login extends StatelessWidget {
  const Login({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => LoginProvider(),
      builder: (context, child) {
        return Consumer<LoginProvider>(
          builder: (context, data, _) {
            return Scaffold(
              body: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text('Login Screen'),
                    Column(
                      children: [
                        TextFormField(
                          decoration: const InputDecoration(
                              labelText: 'User Name'
                          ),
                          onChanged: (value) {

                          },
                        ),
                        TextFormField(
                          decoration: const InputDecoration(
                            labelText: 'Password',
                          ),
                          obscureText: true,
                          onChanged: (value) {

                          },
                        )
                      ],
                    ),
                    Align(
                      alignment: Alignment.centerRight,
                      child: Padding(
                        padding: const EdgeInsets.only(top: 32.0),
                        child: Ink(
                          decoration: const ShapeDecoration(
                            color: AppColors.primaryColorLight,
                            shape: CircleBorder(),
                          ),
                          child: IconButton(
                            icon: const Icon(
                              Icons.arrow_forward,
                              color: AppColors.white,
                            ),
                            onPressed: () {
                              data.loginUser('anil', '123456');
                            },
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ),
            );
          },
        );
      },
    );

  }
}*/
