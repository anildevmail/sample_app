
import 'package:flutter/material.dart';

class LoginInputFields extends StatelessWidget {
  const LoginInputFields({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        TextFormField(
          decoration: const InputDecoration(
            labelText: 'User Name'
          ),
          onChanged: (value) {

          },
        ),
        TextFormField(
          decoration: const InputDecoration(
              labelText: 'Password',
          ),
          obscureText: true,
          onChanged: (value) {

          },
        )
      ],
    );
  }
}
